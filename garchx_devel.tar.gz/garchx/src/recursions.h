void GARCHXRECURSION( int * iStart, int * iEnd, int * iGARCHorder, double * sigma2, double * parsgarch, double * innov );

void GARCHXRECURSIONSIM( int * iStart, int * iEnd, int * iARCHorder, int * iGARCHorder, int * iASYMorder, double * parsarch, double * parsgarch, double * parsasym, double * sigma2, double * z2, double * Ineg, double * xregsum );
