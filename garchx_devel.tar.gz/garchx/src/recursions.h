void GARCHXRECURSION ( int * iStart, int * iEnd, int * iGARCHorder, double * sigma2, double * parsgarch, double * innov );
