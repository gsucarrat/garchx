coef.garchx <-
function(object, ...){ return(object$par) }
