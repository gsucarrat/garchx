nobs.garchx <-
function(object, ...){
  length(residuals.garchx(object))
}
